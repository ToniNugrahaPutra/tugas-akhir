-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Bulan Mei 2021 pada 23.12
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cucian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `laundry`
--

CREATE TABLE `laundry` (
  `id` int(11) NOT NULL,
  `kode_transaksi` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `patokan` varchar(50) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `berat` int(11) NOT NULL,
  `status_cucian` enum('Pengambilan Laundry','Pencucian Laundry','Laundry Selesai','Pengiriman Laundry','Laundry diterima','Tunggu sebentar ya','Cancel') NOT NULL,
  `status_pembayaran` enum('Belum Bayar','Lunas') NOT NULL,
  `ulasan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `laundry`
--

INSERT INTO `laundry` (`id`, `kode_transaksi`, `nama`, `alamat`, `patokan`, `nohp`, `berat`, `status_cucian`, `status_pembayaran`, `ulasan`) VALUES
(4, '04042021-033646', 'diki', 'Jl.LA Sucipto no 214D ', 'depan lapangan', '08123123123', 1, 'Laundry diterima', 'Lunas', 'aku puas!'),
(5, '25042021-005618', 'Aku', 'Jl.Sumpil 2 no 100c', 'Masuk gang seberang mushola hijau', '085257476522', 2, 'Pencucian Laundry', 'Belum Bayar', ''),
(6, '26042021-042459', 'Joko', 'Mangliawan', '', '088230993468', 2, 'Tunggu sebentar ya', 'Belum Bayar', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_created` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `alamat`, `nohp`, `image`, `password`, `role_id`, `date_created`) VALUES
(1, 'Admin', 'admin@gmail.com', 'Sumpil 2 no 100c', '081276249768', 'default.jpg', '$2y$10$9rFAgxmWcNCVp3H385dOo..gzMizUbYQdM9MfboIPv0Bx3OLoLsti', 1, '25/03/2021'),
(5, 'Kurir', 'kurir@gmail.com', 'LA Sucipto 214D', '08123123123', 'default.jpg', '$2y$10$zLnWm0E.SRjHdPHMFZz1VONEbP70iX.ysNM.d8IwEjgXulAqh0RMK', 3, '04/04/2021'),
(6, 'budi', 'budi@gmail.com', 'Singosari', '088230993468', 'default.jpg', '$2y$10$cF6LQZAHU.kebUSjQDD4RODEIUNOJCEngmhO/cgGN/4BgsaflLLza', 2, '04/04/2020'),
(7, 'Bruno', 'bruno@gmail.com', 'Karangploso', '085334945611', 'default.jpg', '$2y$10$w38.u71TPTHuHHJx3yc8A.9UC1WI4G.8oT4CUMz5DjqAFBQ.4OwKi', 2, '25/04/2021'),
(8, 'Joko', 'Joko@gmail.com', 'Mangliawan', '081335558610', 'default.jpg', '$2y$10$sIFCt5xMlWIFcTfKEEOQY.1mgOUK53fRgX1OWT/xKX4gAV5LAyHom', 2, '26/04/2021');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'User'),
(3, 'Kurir');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Kurir'),
(3, 'Member');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(1) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Daftar Pesanan', 'admin/transaksi', 'fas fa-fw fa-shopping-basket', 1),
(2, 1, 'Daftar Users', 'admin', 'fas fa-fw fa-users', 1),
(3, 2, 'My Profile', 'user/profile', 'fas fa-fw fa-users', 1),
(5, 2, 'Form Order', 'user/order', 'fas fa-fw fa-shopping-basket', 1),
(8, 2, 'Riwayat', 'user', 'fas fa-fw fa-history', 1),
(9, 3, 'Daftar Pesanan', 'kurir/transaksi', 'fas fa-fw fa-shopping-basket', 1),
(10, 3, 'My Profile', 'user/profile', 'fas fa-fw fa-users', 1),
(11, 1, 'My Profile', 'user/profile', 'fas fa-fw fa-users', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `laundry`
--
ALTER TABLE `laundry`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `laundry`
--
ALTER TABLE `laundry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
